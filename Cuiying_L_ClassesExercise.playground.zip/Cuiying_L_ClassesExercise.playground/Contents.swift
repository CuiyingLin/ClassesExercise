import UIKit

//features of the car, can be changed
class Car {
    var color = "white"
    var upholstery = "nylon"
    var headlights = "LED Daytime Running Lights"
    var numOfAirbags = "six"
    
    func carDescription(color: String, upholstery: String, headlights: String, numOfAirbags: String) -> String {
        return "\(color) exterior \n\(upholstery) seats \n\(headlights) \n\(numOfAirbags) airbags"
        //new line after each feature
    }
}

//instanced the class
var carSelection = Car()
//reassigned values to the attributes
var sentence = carSelection.carDescription(color: "silver", upholstery: "leather", headlights: "LED Daytime Running Lights", numOfAirbags: "ten")
//prints the result
print("Your car can have the following features: \n" + sentence)
